export const firebaseConfig = {
  "projectId": "studio-7250217791-51ab5",
  "appId": "1:257881770518:web:333eb664534406b7cf4337",
  "apiKey": "AIzaSyCvskxN3l6BnlIFDxQdQE1Ptpi2sL0PjoM",
  "authDomain": "studio-7250217791-51ab5.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "257881770518"
};
